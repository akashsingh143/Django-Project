
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('login', views.loginUser, name='login'),
    path('logout', views.logoutUser, name='logout'),
    path('profile_details', views.profile_details),
    path('profile_update/<int:id>', views.profile_update),
    path('profile_insert', views.profile_insert),
    path('signup', views.signup),
    path('apply/<int:id>', views.apply),

]
