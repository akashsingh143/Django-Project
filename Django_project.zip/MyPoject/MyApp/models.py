from django.db import models
from datetime import date

# Create your models here.


class Contact(models.Model):
    # cid =models.CharField(max_length=20)
    name = models.CharField(max_length=200)
    email = models.CharField(max_length=200)
    phone = models.CharField(max_length=200)
    msg = models.TextField()

    def __str__(self):
        return self.name

    class Meta:
        db_table = "contact_info"


class SignUp(models.Model):
    name = models.CharField(max_length=200)
    username = models.CharField(max_length=200)
    password = models.CharField(max_length=200)
    email = models.CharField(max_length=200)
    location = models.CharField(max_length=200)

    def __str__(self):
        return self.name

    class Meta:
        db_table = "signup"


class UserProfile1(models.Model):
    skills = models.CharField(max_length=200)
    experiences = models.CharField(max_length=1000)
    hedline = models.CharField(max_length=200)
    userid = models.ForeignKey(SignUp, on_delete=models.CASCADE)

    def __str__(self):
        return self.skills

    class Meta:
        db_table = "userprofile1"


class Jobs(models.Model):
    title = models.CharField(max_length=200)
    details = models.CharField(max_length=500)
    exp = models.CharField(max_length=200)

    def __str__(self):
        return self.title

    class Meta:
        db_table = "jobs"


class Apply(models.Model):
    title = models.CharField(max_length=200)
    details = models.CharField(max_length=500)
    exp = models.CharField(max_length=200)
    apdate = models.DateField()
    jobid = models.IntegerField(default=None)
    userid = models.ForeignKey(SignUp, on_delete=models.CASCADE)

    def __str__(self):
        return self.title

    class Meta:
        db_table = "applyjob"
